# Example files
---------------

This folder contains example files for each of the formats supported currently in CKG:

## Proteomics
-----------
-----------

- MaxQuant: `mq_example`

- Spectronaut: `spectronaut_example`

- FragPipe: `fragpipe_example`

- Dia-NN: `dia-nn_example`

- MzTab: `mztab_example`

The `mq_example` is a complete project that can also be used to run the full analysis to generate a project report. The other examples are meant to show only the required format and columns in each format.

To use these files, navigate to `Data Upload` and upload Experimental design, Clinical data (if available in the example) and the proteomics data selecting the tool that was used to processed them.

For more information, follow the instructions in the [docs](https://ckg.readthedocs.io/en/latest/getting_started/upload-data.html)

